# JLCHENA Letters

這是一個使用 Jekyll 架設的靜態網站，記錄歲月與思念的信件。

## 如何部署

1. Clone this repository:
   ```bash
   git clone https://github.com/YOUR_GITHUB_USERNAME/JLCHENA-letters.git
   cd JLCHENA-letters
   ```

2. 啟動本地伺服器
   ```bash
   bundle exec jekyll serve
   ```

3. 上傳到 GitHub，並啟用 GitHub Pages。
